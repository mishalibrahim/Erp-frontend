import type {
  JournalVoucherDto,
  CreateJournalVoucherDto,
  JournalVoucherLineDto,
  JournalVoucherStatus,
  JournalVoucherApprovalStage,
} from "../types";

// Import General Ledger mock data to write entries to the Ledger on Post
import {
  MOCK_GL_TRANSACTIONS,
  MOCK_GL_ACCOUNTS,
} from "../../general-ledger/data/mockGlTransactions";

const LOCAL_STORAGE_KEY = "aegis_journal_vouchers";

// Standard templates seed
export const MOCK_TEMPLATES = [
  {
    name: "General Journal Default",
    journalType: "General" as const,
    currency: "AED",
    description: "Monthly adjustments",
    lines: [
      { accountType: "Ledger" as const, accountId: "a1", debit: 0, credit: 0 },
      { accountType: "Ledger" as const, accountId: "x4", debit: 0, credit: 0 },
    ],
  },
  {
    name: "Rent Expense Accrual",
    journalType: "Accrual" as const,
    currency: "AED",
    description: "Accrued rent for the month",
    lines: [
      { accountType: "Ledger" as const, accountId: "x2", debit: 12000, credit: 0 },
      { accountType: "Ledger" as const, accountId: "l2", debit: 0, credit: 12000 },
    ],
  },
  {
    name: "Office Supplies Adjustment",
    journalType: "Adjusting" as const,
    currency: "AED",
    description: "Office supplies adjustment",
    lines: [
      { accountType: "Ledger" as const, accountId: "x4", debit: 850, credit: 0 },
      { accountType: "Ledger" as const, accountId: "a1", debit: 0, credit: 850 },
    ],
  },
];

// Helper to get account info from GL master
function getAccountInfo(id: string) {
  const acc = MOCK_GL_ACCOUNTS.find((a) => a.id === id);
  return {
    accountNumber: acc?.accountNumber || "",
    accountName: acc?.accountName || "",
  };
}

// Initial seed data
const SEED_VOUCHERS: JournalVoucherDto[] = [
  {
    id: "jv-2026-0020",
    voucherNo: "JV-2026-0020",
    journalName: "GenJrn-2026",
    date: "2026-05-15",
    currency: "AED",
    journalType: "General",
    costCenter: "Admin",
    department: "Finance",
    exchangeRate: 1.0,
    description: "Office supplies expense reconciliation",
    status: "Posted",
    internalNotes: "Reconciliation of petty cash vs office supplies expense.",
    approvalRemarks: "Verified receipts and petty cash log.",
    currentApprovalStage: "Posted",
    approvalHistory: [
      {
        stage: "Initiator",
        action: "Created",
        actor: "Ahmed Khalil",
        timestamp: "2026-05-15T09:00:00Z",
      },
      {
        stage: "Finance Review",
        action: "Approved",
        actor: "Sara Al-Rashid",
        timestamp: "2026-05-15T11:30:00Z",
        remarks: "Lines and balances are correct.",
      },
      {
        stage: "CFO Approve",
        action: "Approved",
        actor: "Layla Hassan",
        timestamp: "2026-05-15T14:15:00Z",
        remarks: "Approved for posting.",
      },
    ],
    lines: [
      {
        id: "l-20-1",
        accountType: "Ledger",
        accountId: "x4",
        accountNumber: "51040",
        accountName: "Office Supplies",
        description: "Reconciliation of office supplies purchases",
        costCenter: "Admin",
        debit: 3500,
        credit: 0,
      },
      {
        id: "l-20-2",
        accountType: "Ledger",
        accountId: "a1",
        accountNumber: "11010",
        accountName: "Cash in Hand",
        description: "Petty cash adjustment",
        costCenter: "Admin",
        debit: 0,
        credit: 3500,
      },
    ],
    attachments: [
      {
        name: "petty_cash_receipts_may2026.pdf",
        size: 2453120,
        type: "application/pdf",
        uploadedAt: "2026-05-15T09:00:00Z",
      },
    ],
  },
  {
    id: "jv-2026-0021",
    voucherNo: "JV-2026-0021",
    journalName: "AdjJrn-2026",
    date: "2026-05-20",
    currency: "USD",
    journalType: "Adjusting",
    costCenter: "Travel & Tourism",
    department: "Operations",
    exchangeRate: 3.6725,
    description: "Consultant fee accrual in USD",
    status: "Pending Approval",
    internalNotes: "Awaiting final invoice copy from US vendor.",
    approvalRemarks: "",
    currentApprovalStage: "Finance Review",
    approvalHistory: [
      {
        stage: "Initiator",
        action: "Submitted",
        actor: "Ahmed Khalil",
        timestamp: "2026-05-20T10:15:00Z",
      },
    ],
    lines: [
      {
        id: "l-21-1",
        accountType: "Ledger",
        accountId: "x5",
        accountNumber: "51050",
        accountName: "Marketing Expense",
        description: "Marketing campaign fee ($3,000 USD)",
        costCenter: "Travel & Tourism",
        debit: 11017.5, // 3000 * 3.6725
        credit: 0,
      },
      {
        id: "l-21-2",
        accountType: "Ledger",
        accountId: "l2",
        accountNumber: "21020",
        accountName: "Accrued Expenses",
        description: "US vendor accrual ($3,000 USD)",
        costCenter: "Travel & Tourism",
        debit: 0,
        credit: 11017.5,
      },
    ],
    attachments: [
      {
        name: "consultant_contract_approved.pdf",
        size: 1045233,
        type: "application/pdf",
        uploadedAt: "2026-05-20T10:14:00Z",
      },
    ],
  },
  {
    id: "jv-2026-0022",
    voucherNo: "JV-2026-0022",
    journalName: "GenJrn-2026",
    date: "2026-05-24",
    currency: "AED",
    journalType: "General",
    costCenter: "Admin",
    department: "HR",
    exchangeRate: 1.0,
    description: "Office kitchen supplies replenishment",
    status: "Draft",
    internalNotes: "Replenished supplies for administrative breakroom.",
    approvalRemarks: "",
    currentApprovalStage: "Initiator",
    approvalHistory: [],
    lines: [
      {
        id: "l-22-1",
        accountType: "Ledger",
        accountId: "x4",
        accountNumber: "51040",
        accountName: "Office Supplies",
        description: "Coffee & snacks replenishment",
        costCenter: "Admin",
        debit: 650,
        credit: 0,
      },
      {
        id: "l-22-2",
        accountType: "Ledger",
        accountId: "a1",
        accountNumber: "11010",
        accountName: "Cash in Hand",
        description: "Petty cash payout",
        costCenter: "Admin",
        debit: 0,
        credit: 650,
      },
    ],
    attachments: [],
  },
];

// Load vouchers from localStorage, or initialize with seed data
function getVouchers(): JournalVoucherDto[] {
  const data = localStorage.getItem(LOCAL_STORAGE_KEY);
  if (!data) {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(SEED_VOUCHERS));
    syncPostedVouchersToGL(SEED_VOUCHERS);
    return SEED_VOUCHERS;
  }
  const vouchers = JSON.parse(data) as JournalVoucherDto[];
  syncPostedVouchersToGL(vouchers);
  return vouchers;
}

// Save vouchers to localStorage
function saveVouchers(vouchers: JournalVoucherDto[]) {
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(vouchers));
  syncPostedVouchersToGL(vouchers);
}

// Function to synchronize posted vouchers to the GL transaction list in memory
function syncPostedVouchersToGL(vouchers: JournalVoucherDto[]) {
  const posted = vouchers.filter((v) => v.status === "Posted");

  posted.forEach((v) => {
    // Check if lines are already in MOCK_GL_TRANSACTIONS
    const exists = MOCK_GL_TRANSACTIONS.some(
      (t) => t.voucherNo === v.voucherNo && t.type === "JV"
    );

    if (!exists) {
      v.lines.forEach((l, index) => {
        MOCK_GL_TRANSACTIONS.push({
          id: `${v.id}-posted-${index}`,
          date: v.date,
          voucherNo: v.voucherNo,
          type: "JV",
          narration: l.description || v.description,
          accountId: l.accountId,
          accountNumber: l.accountNumber,
          accountName: l.accountName,
          costCenter: l.costCenter || v.costCenter || "Admin",
          debit: l.debit,
          credit: l.credit,
          postedBy: v.approvalHistory.find((h) => h.action === "Approved" && h.stage === "CFO Approve")?.actor || "System Admin",
          status: "Posted",
        });
      });
    }
  });
}

// Helper to generate sequential voucher number
function getNextVoucherNumber(vouchers: JournalVoucherDto[]): string {
  const year = new Date().getFullYear();
  const jvsForYear = vouchers.filter((v) => v.voucherNo.startsWith(`JV-${year}-`));
  if (jvsForYear.length === 0) {
    return `JV-${year}-0001`;
  }
  const sequenceNumbers = jvsForYear.map((v) => {
    const parts = v.voucherNo.split("-");
    const numStr = parts[parts.length - 1];
    return parseInt(numStr, 10);
  });
  const maxSeq = Math.max(...sequenceNumbers);
  const nextSeq = maxSeq + 1;
  return `JV-${year}-${nextSeq.toString().padStart(4, "0")}`;
}

export const journalEntriesApi = {
  getAll: async (): Promise<JournalVoucherDto[]> => {
    await new Promise((r) => setTimeout(r, 200));
    return getVouchers();
  },

  getById: async (id: string): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 150));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");
    return v;
  },

  save: async (dto: CreateJournalVoucherDto | JournalVoucherDto): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 200));
    const vouchers = getVouchers();

    let voucher: JournalVoucherDto;

    if ("id" in dto && dto.id) {
      // Edit existing draft
      const idx = vouchers.findIndex((v) => v.id === dto.id);
      if (idx === -1) throw new Error("Voucher not found");
      
      const existing = vouchers[idx];
      if (existing.status !== "Draft" && existing.status !== "Rejected") {
        throw new Error("Only draft or rejected vouchers can be updated.");
      }

      // Map lines with Account Number/Name from Master
      const mappedLines = dto.lines.map((l) => {
        const { accountNumber, accountName } = getAccountInfo(l.accountId);
        return {
          id: "id" in l && l.id ? (l as any).id : `l-${Math.random().toString(36).substr(2, 9)}`,
          accountType: l.accountType,
          accountId: l.accountId,
          accountNumber,
          accountName,
          description: l.description,
          costCenter: l.costCenter,
          debit: l.debit,
          credit: l.credit,
          offsetType: l.offsetType,
          offsetAccountId: l.offsetAccountId,
          ...(l.offsetAccountId ? getAccountInfo(l.offsetAccountId) : {}),
        } as JournalVoucherLineDto;
      });

      voucher = {
        ...existing,
        journalName: dto.journalName,
        date: dto.date,
        currency: dto.currency,
        journalType: dto.journalType,
        costCenter: dto.costCenter,
        department: dto.department,
        exchangeRate: dto.exchangeRate,
        description: dto.description,
        internalNotes: dto.internalNotes || "",
        lines: mappedLines,
        status: "Draft", // resets status back to draft if it was rejected
      };
      
      vouchers[idx] = voucher;
    } else {
      // Create new voucher
      const voucherNo = getNextVoucherNumber(vouchers);
      
      const mappedLines = dto.lines.map((l) => {
        const { accountNumber, accountName } = getAccountInfo(l.accountId);
        return {
          id: `l-${Math.random().toString(36).substr(2, 9)}`,
          accountType: l.accountType,
          accountId: l.accountId,
          accountNumber,
          accountName,
          description: l.description,
          costCenter: l.costCenter,
          debit: l.debit,
          credit: l.credit,
          offsetType: l.offsetType,
          offsetAccountId: l.offsetAccountId,
          ...(l.offsetAccountId ? {
            offsetAccountNumber: getAccountInfo(l.offsetAccountId).accountNumber,
            offsetAccountName: getAccountInfo(l.offsetAccountId).accountName,
          } : {}),
        } as JournalVoucherLineDto;
      });

      voucher = {
        id: `jv-${Math.random().toString(36).substr(2, 9)}`,
        voucherNo,
        journalName: dto.journalName,
        date: dto.date,
        currency: dto.currency,
        journalType: dto.journalType,
        costCenter: dto.costCenter,
        department: dto.department,
        exchangeRate: dto.exchangeRate,
        description: dto.description,
        status: "Draft",
        internalNotes: dto.internalNotes || "",
        approvalRemarks: "",
        currentApprovalStage: "Initiator",
        approvalHistory: [],
        lines: mappedLines,
        attachments: [],
      };

      vouchers.push(voucher);
    }

    saveVouchers(vouchers);
    return voucher;
  },

  delete: async (id: string): Promise<void> => {
    await new Promise((r) => setTimeout(r, 150));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");
    if (v.status !== "Draft" && v.status !== "Rejected") {
      throw new Error("Only draft or rejected vouchers can be deleted.");
    }
    const updated = vouchers.filter((item) => item.id !== id);
    saveVouchers(updated);
  },

  validate: async (voucher: JournalVoucherDto): Promise<{ success: boolean; errors: string[] }> => {
    await new Promise((r) => setTimeout(r, 200));
    const errors: string[] = [];

    // 1. Basic balancing
    const totalDebit = voucher.lines.reduce((s, l) => s + l.debit, 0);
    const totalCredit = voucher.lines.reduce((s, l) => s + l.credit, 0);
    if (Math.abs(totalDebit - totalCredit) >= 0.01) {
      errors.push(`Journal is unbalanced: Total Debits (AED ${(totalDebit * voucher.exchangeRate).toFixed(2)}) must equal Total Credits (AED ${(totalCredit * voucher.exchangeRate).toFixed(2)}).`);
    }

    // 2. Open Period Check (Jan 2026 - Dec 2026 open, standard in mock)
    const date = new Date(voucher.date);
    const year = date.getFullYear();
    if (isNaN(date.getTime()) || year !== 2026) {
      errors.push(`Voucher Date ${voucher.date} falls outside the open fiscal period (Year 2026).`);
    }

    // 3. Line count check
    if (voucher.lines.length < 2) {
      errors.push("At least 2 lines are required for a double-entry posting.");
    }

    // 4. Line field selections
    voucher.lines.forEach((l, i) => {
      if (!l.accountId) errors.push(`Line ${i + 1}: Account selection is mandatory.`);
      if (l.debit === 0 && l.credit === 0) errors.push(`Line ${i + 1}: Must specify a Debit or Credit amount.`);
      if (l.debit > 0 && l.credit > 0) errors.push(`Line ${i + 1}: Cannot have both a Debit and a Credit amount.`);
    });

    // 5. Exchange Rate check
    if (voucher.currency !== "AED" && voucher.exchangeRate <= 0) {
      errors.push("Exchange Rate must be greater than zero for foreign currencies.");
    }

    return {
      success: errors.length === 0,
      errors,
    };
  },

  simulate: async (voucher: JournalVoucherDto): Promise<any[]> => {
    await new Promise((r) => setTimeout(r, 300));
    
    // Generates a mock preview of double entry items
    return voucher.lines.map((l) => ({
      accountId: l.accountId,
      accountNumber: l.accountNumber,
      accountName: l.accountName,
      costCenter: l.costCenter || voucher.costCenter || "Admin",
      debit: l.debit * voucher.exchangeRate, // base currency value
      credit: l.credit * voucher.exchangeRate, // base currency value
      currency: "AED", // base currency of the GL postings
      foreignDebit: voucher.currency !== "AED" ? l.debit : 0,
      foreignCredit: voucher.currency !== "AED" ? l.credit : 0,
      foreignCurrency: voucher.currency,
    }));
  },

  sendForApproval: async (id: string): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 200));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");
    if (v.status !== "Draft" && v.status !== "Rejected") {
      throw new Error("Voucher must be in Draft or Rejected status to send for approval.");
    }

    v.status = "Pending Approval";
    v.currentApprovalStage = "Finance Review";
    v.approvalHistory.push({
      stage: "Initiator",
      action: "Submitted",
      actor: "Ahmed Khalil",
      timestamp: new Date().toISOString(),
    });

    saveVouchers(vouchers);
    return v;
  },

  approve: async (id: string, remarks?: string): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 200));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");
    if (v.status !== "Pending Approval") {
      throw new Error("Voucher is not pending approval.");
    }

    const currentStage = v.currentApprovalStage;
    let nextStage: JournalVoucherApprovalStage;
    let nextStatus: JournalVoucherStatus = "Pending Approval";

    // Standard Matrix logic
    // Compute total voucher value in base currency (AED)
    const totalDebitForeign = v.lines.reduce((s, l) => s + l.debit, 0);
    const totalDebitBase = totalDebitForeign * v.exchangeRate;

    if (currentStage === "Finance Review") {
      // If amount <= AED 50,000, then Finance Review approval directly approves the voucher
      if (totalDebitBase <= 50000) {
        nextStage = "Posted"; // bypasses CFO approval
        nextStatus = "Approved"; // eligible for posting
      } else {
        nextStage = "CFO Approve";
        nextStatus = "Pending Approval";
      }
      
      v.approvalHistory.push({
        stage: "Finance Review",
        action: "Approved",
        actor: "Sara Al-Rashid",
        timestamp: new Date().toISOString(),
        remarks: remarks || "Validated lines, cost centers and balance check.",
      });
    } else if (currentStage === "CFO Approve") {
      nextStage = "Posted";
      nextStatus = "Approved";
      
      v.approvalHistory.push({
        stage: "CFO Approve",
        action: "Approved",
        actor: "Layla Hassan",
        timestamp: new Date().toISOString(),
        remarks: remarks || "Approved.",
      });
    } else {
      throw new Error("Invalid stage transition");
    }

    v.currentApprovalStage = nextStage;
    v.status = nextStatus;

    saveVouchers(vouchers);
    return v;
  },

  reject: async (id: string, remarks?: string): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 200));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");
    if (v.status !== "Pending Approval") {
      throw new Error("Voucher is not pending approval.");
    }

    const currentStage = v.currentApprovalStage;
    v.status = "Rejected";
    v.currentApprovalStage = "Initiator";
    v.approvalRemarks = remarks || "";
    v.approvalHistory.push({
      stage: currentStage,
      action: "Rejected",
      actor: currentStage === "Finance Review" ? "Sara Al-Rashid" : "Layla Hassan",
      timestamp: new Date().toISOString(),
      remarks: remarks || "Rejected. Please correct balance details.",
    });

    saveVouchers(vouchers);
    return v;
  },

  post: async (id: string): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 250));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");
    if (v.status !== "Approved") {
      throw new Error("Voucher must be Approved before posting.");
    }

    v.status = "Posted";
    v.currentApprovalStage = "Posted";
    v.approvalHistory.push({
      stage: "Posted",
      action: "Posted",
      actor: "Ahmed Khalil",
      timestamp: new Date().toISOString(),
    });

    // Reversing Voucher automation logic
    let reversingVoucherId: string | undefined = undefined;
    if (v.journalType === "Reversing") {
      // Automatic reversal generation in local storage
      const nextVoucherNo = getNextVoucherNumber(vouchers);
      
      // Swap debits and credits
      const reversedLines = v.lines.map((l) => ({
        id: `l-${Math.random().toString(36).substr(2, 9)}`,
        accountType: l.accountType,
        accountId: l.accountId,
        accountNumber: l.accountNumber,
        accountName: l.accountName,
        description: `Reversal of ${v.voucherNo} - ${l.description || ""}`,
        costCenter: l.costCenter,
        debit: l.credit,
        credit: l.debit,
        offsetType: l.offsetType,
        offsetAccountId: l.offsetAccountId,
        offsetAccountNumber: l.offsetAccountNumber,
        offsetAccountName: l.offsetAccountName,
      }));

      // Next period date: 1st of next month
      const voucherDate = new Date(v.date);
      const nextMonthDate = new Date(voucherDate.getFullYear(), voucherDate.getMonth() + 1, 1);
      const nextMonthStr = nextMonthDate.toISOString().split("T")[0];

      const reversingVoucher: JournalVoucherDto = {
        id: `jv-${Math.random().toString(36).substr(2, 9)}`,
        voucherNo: nextVoucherNo,
        journalName: v.journalName,
        date: nextMonthStr,
        currency: v.currency,
        journalType: "General", // The reversing entry itself is general
        costCenter: v.costCenter,
        department: v.department,
        exchangeRate: v.exchangeRate,
        description: `Auto-reversal of voucher ${v.voucherNo}`,
        status: "Draft",
        internalNotes: `Auto-generated reversing entry for accrual voucher ${v.voucherNo}.`,
        approvalRemarks: "",
        currentApprovalStage: "Initiator",
        approvalHistory: [],
        lines: reversedLines,
        attachments: [],
        reversedVoucherId: v.id,
      };

      vouchers.push(reversingVoucher);
      reversingVoucherId = reversingVoucher.id;
      v.reversingVoucherId = reversingVoucherId;
    }

    saveVouchers(vouchers);
    return v;
  },

  reverse: async (id: string): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 250));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");
    if (v.status !== "Posted") {
      throw new Error("Only posted vouchers can be reversed.");
    }

    v.status = "Reversed";

    // Generate reversing draft
    const nextVoucherNo = getNextVoucherNumber(vouchers);
    const reversedLines = v.lines.map((l) => ({
      id: `l-${Math.random().toString(36).substr(2, 9)}`,
      accountType: l.accountType,
      accountId: l.accountId,
      accountNumber: l.accountNumber,
      accountName: l.accountName,
      description: `Reversal of ${v.voucherNo} - ${l.description || ""}`,
      costCenter: l.costCenter,
      debit: l.credit,
      credit: l.debit,
      offsetType: l.offsetType,
      offsetAccountId: l.offsetAccountId,
      offsetAccountNumber: l.offsetAccountNumber,
      offsetAccountName: l.offsetAccountName,
    }));

    const reversingVoucher: JournalVoucherDto = {
      id: `jv-${Math.random().toString(36).substr(2, 9)}`,
      voucherNo: nextVoucherNo,
      journalName: v.journalName,
      date: new Date().toISOString().split("T")[0],
      currency: v.currency,
      journalType: "General",
      costCenter: v.costCenter,
      department: v.department,
      exchangeRate: v.exchangeRate,
      description: `Manual Reversal of voucher ${v.voucherNo}`,
      status: "Draft",
      internalNotes: `Manually generated reversal for voucher ${v.voucherNo}.`,
      approvalRemarks: "",
      currentApprovalStage: "Initiator",
      approvalHistory: [],
      lines: reversedLines,
      attachments: [],
      reversedVoucherId: v.id,
    };

    vouchers.push(reversingVoucher);
    v.reversingVoucherId = reversingVoucher.id;

    saveVouchers(vouchers);
    return reversingVoucher;
  },

  // Files simulation
  addAttachment: async (id: string, file: { name: string; size: number; type: string }): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 100));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");

    v.attachments.push({
      ...file,
      uploadedAt: new Date().toISOString(),
    });

    saveVouchers(vouchers);
    return v;
  },

  removeAttachment: async (id: string, fileName: string): Promise<JournalVoucherDto> => {
    await new Promise((r) => setTimeout(r, 100));
    const vouchers = getVouchers();
    const v = vouchers.find((item) => item.id === id);
    if (!v) throw new Error("Voucher not found");

    v.attachments = v.attachments.filter((f) => f.name !== fileName);

    saveVouchers(vouchers);
    return v;
  },
};
