import type {
  GlTransactionDto,
  GlLedgerFilterParams,
  GlPeriodOption,
  GlCostCenterOption,
  GlAccountOption,
} from "../types";
import {
  MOCK_GL_TRANSACTIONS,
  MOCK_OPENING_BALANCES,
  MOCK_PERIODS,
  MOCK_COST_CENTERS,
  MOCK_GL_ACCOUNTS,
} from "../data/mockGlTransactions";

/**
 * General Ledger API service layer.
 *
 * Currently backed by mock data. When the backend API is ready,
 * swap the implementations to use axiosClient + API_ENDPOINTS
 * without touching hooks or components.
 */
export const generalLedgerApi = {
  /**
   * Fetch GL transactions matching the given filters.
   * Returns rows sorted by date ascending.
   */
  getTransactions: async (
    filters: GlLedgerFilterParams
  ): Promise<GlTransactionDto[]> => {
    // Simulate network delay
    await new Promise((r) => setTimeout(r, 300));

    let rows = [...MOCK_GL_TRANSACTIONS];

    // ── Account filter ──────────────────────────────────────────────────
    if (filters.accountId) {
      rows = rows.filter((r) => r.accountId === filters.accountId);
    }

    // ── Period filter ───────────────────────────────────────────────────
    if (filters.periodValue) {
      const period = MOCK_PERIODS.find((p) => p.value === filters.periodValue);
      if (period) {
        const start = new Date(period.startDate);
        const end = new Date(period.endDate);
        rows = rows.filter((r) => {
          const d = new Date(r.date);
          return d >= start && d <= end;
        });
      }
    }

    // ── Cost Center filter ──────────────────────────────────────────────
    if (filters.costCenter && filters.costCenter !== "all") {
      rows = rows.filter((r) => r.costCenter === filters.costCenter);
    }

    // ── Type filter ─────────────────────────────────────────────────────
    if (filters.type) {
      rows = rows.filter((r) => r.type === filters.type);
    }

    // Sort by date ascending (default)
    rows.sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    return rows;
  },

  /**
   * Fetch the opening balance for a specific account at the start of a period.
   * Returns 0 for "All Accounts".
   */
  getOpeningBalance: async (
    accountId?: string,
    _periodValue?: string
  ): Promise<number> => {
    await new Promise((r) => setTimeout(r, 100));

    if (!accountId) return 0; // "All Accounts" → zero per FRD §6.2

    return MOCK_OPENING_BALANCES[accountId] ?? 0;
  },

  /**
   * Fetch available accounting periods.
   */
  getPeriods: async (): Promise<GlPeriodOption[]> => {
    await new Promise((r) => setTimeout(r, 50));
    return MOCK_PERIODS;
  },

  /**
   * Fetch cost center options.
   */
  getCostCenters: async (): Promise<GlCostCenterOption[]> => {
    await new Promise((r) => setTimeout(r, 50));
    return MOCK_COST_CENTERS;
  },

  /**
   * Fetch GL accounts for the filter dropdown.
   * Groups accounts by category.
   */
  getAccounts: async (): Promise<GlAccountOption[]> => {
    await new Promise((r) => setTimeout(r, 50));
    return MOCK_GL_ACCOUNTS;
  },
};
